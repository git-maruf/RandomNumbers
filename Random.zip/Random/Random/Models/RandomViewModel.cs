﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Random.Models
{
    public class RandomViewModel
    {
        public int TotalRecord { get; set; }
        public int TotalNumeric { get; set; }
        public int NumericPer { get; set; }
        public int TotalFloat { get; set; }
        public int FloatPer { get; set; }
        public int TotalAlpha { get; set; }
        public int AlphaPer { get; set; }
    }
}
