﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Grpc.Core;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Random.Models;

namespace Random.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private IHostingEnvironment _env;

        public HomeController(ILogger<HomeController> logger, IHostingEnvironment env)
        {
            _logger = logger;
            _env = env;
        }

        public IActionResult Page1()
        {
            var path = Path.Combine(_env.ContentRootPath, @"Content\" + "RandomData.txt");
            if(!System.IO.File.Exists(path))
            {
                using (FileStream fs = System.IO.File.Create(path)) { }
            }
            
            return View();
        }

        public IActionResult Page2()
        {
            var model = new RandomViewModel();
            try
            {
                var path = Path.Combine(_env.ContentRootPath, @"Content\" + "RandomData.txt");
                string contents = "";
                using (StreamReader streamReader = new StreamReader(path, Encoding.UTF8))
                {
                    contents = streamReader.ReadToEnd();
                }
                List<string> items = contents.Split(',').ToList<string>();

                int numCounter = 0, floCounter = 0, alpCounter = 0;
                foreach (var item in items)
                {
                    if (item == "") { continue; }
                    int intValue;
                    float floatValue;
                    if (Int32.TryParse(item, out intValue))
                    {
                        numCounter++;
                    }
                    else if (float.TryParse(item, out floatValue))
                    {
                        floCounter++;
                    }
                    else { alpCounter++; }
                }

                model.TotalNumeric = numCounter;
                model.TotalFloat = floCounter;
                model.TotalAlpha = alpCounter;
                model.TotalRecord = numCounter + floCounter + alpCounter;
                model.NumericPer = 0;
                model.FloatPer = 0;
                model.AlphaPer = 0;
                if (model.TotalNumeric > 0)
                {
                    model.NumericPer = (100 * model.TotalNumeric) / model.TotalRecord;
                }
                if (model.TotalFloat > 0)
                {
                    model.FloatPer = (100 * model.TotalFloat) / model.TotalRecord;
                }
                if (model.TotalAlpha > 0)
                {
                    model.AlphaPer = (100 * model.TotalAlpha) / model.TotalRecord;
                }
                return View(model);
            }
            catch (Exception ex)
            {

                return View(model);
            }
            

            

          
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        [HttpPost]
        public async Task<IActionResult> StoreRandomString(string randomString, int kb=0)
        {
            
            //path of file
            var path = Path.Combine(_env.ContentRootPath, @"Content\" + "RandomData.txt");
            //var path = @"E:\TheCodeHubs.txt";
            FileInfo fi = new FileInfo(path);
            long fileSize = fi.Length;
          
            if (kb>0 && fileSize > (kb * 1000))
            {
                return Ok(new { response = "0",status= "file size exceeded" });
            }

            using (StreamWriter sw = new StreamWriter(path,true))
            {
                sw.Write(randomString);
            }
            return Ok(new { response = "1", status="ok" });
        }
    }
}
